# Wake Me at My Stop — Android OSM starter (0.2-alpha)

## Included
- White/frosted-glass inspired Android UI with green accents
- Destination search using OpenStreetMap Nominatim
- Route ETA queries using OSRM's public demo routing endpoint
- Foreground location service and persistent tracking notification
- Language selector (English, Malayalam, Hindi, Tamil, Kannada, Telugu, Arabic)
- Alert lead-time settings (1, 2, 5, 10 minutes)
- Basic sound selection and vibration toggle
- ₹2 one-time premium ringtone UI placeholder

## Critical limitations
- This is an untested starter project, not a production-ready app.
- OSRM is queried from the current GPS position to the selected destination using the driving profile. It does not know the bus's actual route, does not provide live traffic, and may not have all roads/regions. ETA may be inaccurate.
- The public Nominatim/OSRM endpoints have usage policies and are not guaranteed production services. For public release, choose suitable hosted services, follow usage policies, add caching/rate limits and attribution, and evaluate availability/coverage.
- The language selector stores the chosen language and changes the app title for Malayalam; full translations are not yet implemented.
- Sound selection currently maps to a few built-in tones, not arbitrary user-picked audio files.
- ₹2 purchase is only a UI placeholder. No real payment is taken and premium is not securely unlocked. Add Google Play Billing, a Play Console product, server/Play purchase verification and restore-purchases handling before accepting payments.
- Background location access and notification permission flow need proper Android-version-specific handling. Android/OEM battery restrictions may stop tracking. Test on device.
- No iOS app is included.

## Build on an Android phone
1. Download and extract the ZIP.
2. Create a GitHub repository and upload all files at the repository root, preserving folders.
3. Open Actions and run `Build Android APK`. The workflow at `.github/workflows/android.yml` builds a debug APK.
4. Download the `WakeMeAtMyStop-debug-apk` artifact from the completed workflow.
5. Extract the APK and install it on your Android phone. Allow installation from that browser/file manager if prompted.
6. Grant location and notifications. Search and select the exact stop; start tracking. Test on a short, familiar route and keep a backup alarm.

## Recommended production milestones
1. Replace public demo routing with a reliable hosted OSRM/Valhalla/GraphHopper service and a route-following/matching strategy.
2. Add Android background location permission UX and test Doze/OEM battery behavior.
3. Complete translations, ringtone file picker, preview and user preferences.
4. Implement Google Play Billing for the one-time ₹2 product and server-side verification.
5. Add privacy policy, data minimization, map attribution and release testing.
