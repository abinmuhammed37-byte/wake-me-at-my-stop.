package com.wakeme.stop

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Place(val name: String, val lat: Double, val lon: Double)

object PlaceSearch {
    fun search(query: String): List<Place> {
        if (query.isBlank()) return emptyList()
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val connection = URL("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&countrycodes=in&q=$encoded").openConnection() as HttpURLConnection
            connection.connectTimeout = 10000
            connection.readTimeout = 10000
            connection.setRequestProperty("User-Agent", "WakeMeAtMyStopAndroid/0.2 (prototype)")
            connection.setRequestProperty("Accept-Language", "en,ml")
            val text = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()
            val array = JSONArray(text)
            (0 until array.length()).mapNotNull { i ->
                val item = array.getJSONObject(i)
                val lat = item.optString("lat").toDoubleOrNull()
                val lon = item.optString("lon").toDoubleOrNull()
                if (lat == null || lon == null) null else Place(item.optString("display_name"), lat, lon)
            }
        } catch (_: Exception) { emptyList() }
    }
}
