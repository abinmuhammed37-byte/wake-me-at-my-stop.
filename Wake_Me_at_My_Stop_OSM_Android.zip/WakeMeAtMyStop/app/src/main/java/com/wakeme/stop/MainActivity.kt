package com.wakeme.stop

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val Green = Color(0xFF137B58)
private val Ink = Color(0xFF14231C)
private val Glass = Color(0xDFFFFFFF)

class MainActivity : ComponentActivity() {
    private var locationGranted by mutableStateOf(false)
    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        locationGranted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        locationGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val prefs = getSharedPreferences("wakeme", MODE_PRIVATE)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Color(0xFFF4F8F5))) {
                var language by remember { mutableStateOf(prefs.getString("language", "English") ?: "English") }
                var query by remember { mutableStateOf("Vettillappara") }
                var selected by remember { mutableStateOf<Place?>(null) }
                var results by remember { mutableStateOf(listOf<Place>()) }
                var minutes by remember { mutableIntStateOf(prefs.getInt("minutes", 2)) }
                var ringtone by remember { mutableStateOf(prefs.getString("ringtone", "Default alarm") ?: "Default alarm") }
                var vibration by remember { mutableStateOf(prefs.getBoolean("vibration", true)) }
                var status by remember { mutableStateOf("Search and select the exact destination.") }
                var searching by remember { mutableStateOf(false) }
                var showSettings by remember { mutableStateOf(false) }
                var premiumUnlocked by remember { mutableStateOf(prefs.getBoolean("premium_unlocked", false)) }

                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.White, Color(0xFFE6F1EA), Color(0xFFF8FAF9))))) {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(48.dp).background(Brush.linearGradient(listOf(Color.White, Color(0xFFD8F5E7), Color(0xFFEAF4EE))), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                                Text("⌖", color = Green, style = MaterialTheme.typography.displaySmall)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if(language=="മലയാളം") "വേക്ക് മീ അറ്റ് മൈ സ്റ്റോപ്പ്" else "Wake Me at My Stop", color = Ink, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                                Text("OpenStreetMap · White Liquid Glass", color = Color(0xFF64746B), style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(onClick = { showSettings = !showSettings }) { Text(if(showSettings) "Home" else "Settings") }
                        }

                        if (showSettings) {
                            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(24.dp)) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("Settings", color = Ink, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text("App language", color = Ink, fontWeight = FontWeight.SemiBold)
                                    var langExpanded by remember { mutableStateOf(false) }
                                    Box {
                                        OutlinedButton(onClick = { langExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(language) }
                                        DropdownMenu(expanded = langExpanded, onDismissRequest = { langExpanded = false }) {
                                            listOf("English", "മലയാളം", "हिन्दी", "தமிழ்", "ಕನ್ನಡ", "తెలుగు", "العربية").forEach { lang ->
                                                DropdownMenuItem(text = { Text(lang) }, onClick = { language = lang; prefs.edit().putString("language", lang).apply(); langExpanded = false })
                                            }
                                        }
                                    }
                                    Text("Alarm sound", color = Ink, fontWeight = FontWeight.SemiBold)
                                    var toneExpanded by remember { mutableStateOf(false) }
                                    Box {
                                        OutlinedButton(onClick = { toneExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(ringtone + if(premiumUnlocked) " · Premium unlocked" else "") }
                                        DropdownMenu(expanded = toneExpanded, onDismissRequest = { toneExpanded = false }) {
                                            listOf("Default alarm", "Classic beep", "Urgent siren", "Premium chime (₹2)").forEach { tone ->
                                                DropdownMenuItem(text = { Text(tone) }, onClick = {
                                                    toneExpanded = false
                                                    if (tone == "Premium chime (₹2)" && !premiumUnlocked) status = "Payment is not connected yet. Premium purchase is a placeholder."
                                                    else { ringtone = tone; prefs.edit().putString("ringtone", tone).apply(); status = "Selected $tone" }
                                                })
                                            }
                                        }
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Vibration", color = Ink, modifier = Modifier.weight(1f))
                                        Switch(checked = vibration, onCheckedChange = { vibration = it; prefs.edit().putBoolean("vibration", it).apply() })
                                    }
                                    Text("Premium ringtone unlock: ₹2 one-time. Real payment is not configured in this prototype.", color = Color(0xFF65736C), style = MaterialTheme.typography.bodySmall)
                                    Button(onClick = { status = "Premium billing placeholder only. Configure Google Play Billing before accepting payments." }, modifier = Modifier.fillMaxWidth()) { Text(if(premiumUnlocked) "Premium unlocked" else "Unlock Premium · ₹2") }
                                }
                            }
                        } else {
                            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(28.dp)) {
                                Column(Modifier.padding(22.dp)) {
                                    Text("YOUR NEXT STOP", color = Green, fontWeight = FontWeight.Bold)
                                    Text(selected?.name ?: "Choose a destination", color = Ink, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                                    Text("Alarm $minutes minutes before estimated road arrival", color = Color(0xFF64746B))
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(24.dp)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("Where do you want to get off?", color = Ink, fontWeight = FontWeight.Bold)
                                    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Town, stop or landmark") }, singleLine = true)
                                    Button(onClick = {
                                        searching = true; status = "Searching OpenStreetMap…"
                                        Thread { val found = PlaceSearch.search(query); runOnUiThread { results = found; searching = false; status = if(found.isEmpty()) "No results. Check internet or try a nearby town." else "Choose the exact result." } }
                                    }, modifier = Modifier.fillMaxWidth()) { Text(if(searching) "Searching…" else "Search destination") }
                                    results.forEach { p ->
                                        TextButton(onClick = { selected = p; status = "Selected destination: ${p.name}" }, modifier = Modifier.fillMaxWidth()) {
                                            Column(Modifier.fillMaxWidth()) { Text(p.name, color = Ink); Text("${p.lat}, ${p.lon}", color = Color.Gray, style = MaterialTheme.typography.labelSmall) }
                                        }
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text("Alert before arrival", color = Ink, fontWeight = FontWeight.SemiBold)
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf(1, 2, 5, 10).forEach { m -> FilterChip(selected = minutes == m, onClick = { minutes = m; prefs.edit().putInt("minutes", m).apply() }, label = { Text("$m min") }) }
                                    }
                                }
                            }
                            Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(24.dp)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("Trip monitor", color = Ink, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                    Text(status, color = Color(0xFF607169), modifier = Modifier.padding(vertical = 10.dp))
                                    Button(onClick = {
                                        val p = selected
                                        if (p == null) status = "Search and select your exact destination first."
                                        else if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                                            val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                                            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
                                            permissionRequest.launch(perms.toTypedArray()); status = "Grant location permission, then press Start trip again."
                                        } else {
                                            val i = Intent(this@MainActivity, TripTrackingService::class.java).apply {
                                                action = TripTrackingService.ACTION_START
                                                putExtra("name", p.name); putExtra("lat", p.lat); putExtra("lon", p.lon)
                                                putExtra("mins", minutes); putExtra("vibration", vibration); putExtra("ringtone", ringtone)
                                            }
                                            ContextCompat.startForegroundService(this@MainActivity, i)
                                            status = "Tracking started. Check the persistent notification."
                                        }
                                    }, modifier = Modifier.fillMaxWidth()) { Text("▶ Start trip tracking") }
                                    OutlinedButton(onClick = { stopService(Intent(this@MainActivity, TripTrackingService::class.java)); status = "Tracking stopped." }, modifier = Modifier.fillMaxWidth()) { Text("Stop trip") }
                                }
                            }
                        }
                        Text("Prototype only: route estimates use OSRM car routes, not live bus GPS or live traffic. Test carefully and keep a backup alarm.", color = Color(0xFF65736C), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
