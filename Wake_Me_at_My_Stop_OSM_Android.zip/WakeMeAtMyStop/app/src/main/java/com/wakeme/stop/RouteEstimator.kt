package com.wakeme.stop

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class RouteEstimate(val meters: Double, val seconds: Double, val label: String)

object RouteEstimator {
    // OSRM public demo endpoint: route from current GPS point to destination.
    // This is a car-road route estimate, not the bus route or live traffic.
    fun estimate(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double): RouteEstimate? {
        return try {
            val url = "https://router.project-osrm.org/route/v1/driving/$fromLon,$fromLat;$toLon,$toLat?overview=false&steps=false"
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "WakeMeAtMyStopAndroid/0.2")
            val body = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val json = JSONObject(body)
            if (json.optString("code") != "Ok" || json.optJSONArray("routes")?.length() == 0) null
            else {
                val r = json.getJSONArray("routes").getJSONObject(0)
                RouteEstimate(r.getDouble("distance"), r.getDouble("duration"),
                    String.format(Locale.US, "%.1f km · ~%d min", r.getDouble("distance") / 1000, kotlin.math.ceil(r.getDouble("duration") / 60).toInt()))
            }
        } catch (_: Exception) { null }
    }
}
