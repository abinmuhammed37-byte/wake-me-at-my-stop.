package com.wakeme.stop

import android.app.*
import android.content.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.*
import java.util.Locale
import kotlin.math.ceil

class TripTrackingService : Service() {
    companion object {
        const val ACTION_START = "com.wakeme.stop.START"
        private const val TRACK_CHANNEL = "trip_tracking"
        private const val ALARM_CHANNEL = "arrival_alarm"
    }
    private lateinit var client: FusedLocationProviderClient
    private lateinit var callback: LocationCallback
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var targetLat = 0.0
    private var targetLon = 0.0
    private var targetName = "your stop"
    private var minutes = 2
    private var vibrationEnabled = true
    private var ringtone = "Default alarm"
    private var alarmed = false
    private var routeBusy = false
    private var lastRouteAt = 0L

    override fun onCreate() {
        super.onCreate()
        client = LocationServices.getFusedLocationProviderClient(this)
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(TRACK_CHANNEL, "Trip tracking", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(ALARM_CHANNEL, "Arrival alarm", NotificationManager.IMPORTANCE_HIGH).apply { enableVibration(true) })
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) { stopSelf(); return START_NOT_STICKY }
        targetName = intent.getStringExtra("name") ?: "your stop"
        targetLat = intent.getDoubleExtra("lat", 0.0)
        targetLon = intent.getDoubleExtra("lon", 0.0)
        minutes = intent.getIntExtra("mins", 2).coerceIn(1, 30)
        vibrationEnabled = intent.getBooleanExtra("vibration", true)
        ringtone = intent.getStringExtra("ringtone") ?: "Default alarm"
        alarmed = false
        startForeground(7, trackingNotification("Tracking toward $targetName"))
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L).setMinUpdateIntervalMillis(3000L).setMinUpdateDistanceMeters(5f).build()
        callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val loc = result.lastLocation ?: return
                val now = System.currentTimeMillis()
                if (!routeBusy && now - lastRouteAt > 20000) {
                    routeBusy = true; lastRouteAt = now
                    scope.launch {
                        val route = RouteEstimator.estimate(loc.latitude, loc.longitude, targetLat, targetLon)
                        withContext(Dispatchers.Main) {
                            routeBusy = false
                            if (route != null) {
                                getSystemService(NotificationManager::class.java).notify(7, trackingNotification("Road route: ${route.label}"))
                                if (!alarmed && route.seconds <= minutes * 60.0) { alarmed = true; triggerAlarm() }
                            } else {
                                getSystemService(NotificationManager::class.java).notify(7, trackingNotification("GPS active · route service unavailable; retrying"))
                            }
                        }
                    }
                }
            }
        }
        try { client.requestLocationUpdates(request, callback, mainLooper) } catch (_: SecurityException) { stopSelf() }
        return START_STICKY
    }
    private fun trackingNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, TRACK_CHANNEL).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Wake Me at My Stop").setContentText(text).setOngoing(true).setContentIntent(pi).build()
    }
    private fun triggerAlarm() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(8, NotificationCompat.Builder(this, ALARM_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Your stop is coming up!")
            .setContentText("Get ready to get off at $targetName.")
            .setPriority(NotificationCompat.PRIORITY_MAX).setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setOngoing(true).build())
        try {
            val type = when (ringtone) { "Classic beep" -> ToneGenerator.TONE_PROP_BEEP; "Urgent siren" -> ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD; else -> ToneGenerator.TONE_PROP_ACK }
            val tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            scope.launch { repeat(12) { tone.startTone(type, 700); delay(900) }; tone.release() }
        } catch (_: Exception) {}
        if (vibrationEnabled) try {
            if (Build.VERSION.SDK_INT >= 31) (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500, 200, 900), -1))
            else @Suppress("DEPRECATION") (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500, 200, 900), -1))
        } catch (_: Exception) {}
    }
    override fun onDestroy() { try { client.removeLocationUpdates(callback) } catch (_: Exception) {}; scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
